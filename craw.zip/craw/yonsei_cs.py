# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_num = 1333
id_num=2356

while True:
	driver.get('http://cs.yonsei.ac.kr/cs/sub05_1.php?page=1&nSeq=3')

	recent_num = driver.find_element_by_xpath('//*[@id="container"]/div[2]/div[1]/div/table/tbody/tr[2]/td[1]/strong').text

	while True:
		if int(recent_num) > last_num:
			
			id_num=id_num+1

			driver.get('http://cs.yonsei.ac.kr/cs/sub05_1_view.php?id='+str(id_num)+'&page=1&&nSeq=3')

			title = driver.find_element_by_xpath('//*[@id="container"]/div[2]/div[1]/div/table[1]/tbody/tr[1]/th[3]').text
			if not title:
				continue
			last_num=last_num+1
			
			contents = driver.find_element_by_xpath('//*[@id="container"]/div[2]/div[1]/div/div[1]/div').text

			print(title)
			print(contents)
		else:
			break


	sleep(100)

