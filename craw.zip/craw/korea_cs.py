# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_num = 409

while True:
	driver.get('https://info.korea.ac.kr/cs/board/course.do')

	recent_num = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/div[2]/table/tbody/tr[1]/td[1]').text

	while True:
		if int(recent_num) > last_num:

			driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/div[2]/table/tbody/tr[1]/td[2]/a').click()
			
			title = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/table/tbody/tr[1]/td').text
		
			last_num=last_num+1
			
			contents = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/table/tbody/tr[2]/td/div').text

			print(title)
			print(contents)
		else:
			break


	sleep(100)

