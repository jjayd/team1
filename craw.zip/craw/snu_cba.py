# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_num = 11472

while True:
	driver.get('https://cba.snu.ac.kr/ko/job-postings')

	recent_num = driver.find_element_by_xpath('//*[@id="p4_23"]/table/tbody/tr[3]/td[1]').text
	
	while True:
		if int(recent_num) > last_num:
			driver.find_element_by_xpath('//*[@id="p4_23"]/table/tbody/tr[3]/td[2]/a').click()

			title = driver.find_element_by_xpath('//*[@id="p4_23"]/table[2]/tbody/tr[1]/td').text
			contents = driver.find_element_by_xpath('//*[@id="p4_23"]/div').text

			print(title)
			print(contents)

		else:
			break

	sleep(100)