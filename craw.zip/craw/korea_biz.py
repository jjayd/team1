# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_com = "딜로이트 안진회계법인"

while True:
	driver.get('https://biz1.korea.ac.kr/ko/recruitment')

	recent_com = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/div[2]/table/tbody/tr[1]/td[1]').text

	print(str(recent_com))

	while True:
		if str(recent_com) != last_com:

			driver.find_element_by_xpath('//*[@id="block-views-job-list-block-2"]/div/div/div[3]/table[2]/tbody/tr[1]/td[1]/a').click()
			
			last_com = recent_com

			title = driver.find_element_by_xpath('//*[@id="content"]/article/div[1]/div[1]/a').text
			
			contents = driver.find_element_by_xpath('//*[@id="content"]/article/div[2]/div[7]').text

			print(title)
			print(contents)
		else:
			break


	sleep(100)

