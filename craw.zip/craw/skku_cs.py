# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_num = 2772

while True:
	driver.get('http://cs.skku.edu/news/recruit/list')

	recent_num = driver.find_element_by_xpath('//*[@id="boardList"]/tbody/tr[2]/td[1]').text
	while True:
		if int(recent_num) > last_num:
			last_num=last_num+1
			driver.get('http://cs.skku.edu/news/recruit/view/'+str(last_num))

			title = driver.find_element_by_xpath('//*[@id="title"]').text
			if not title:
				continue
			contents = driver.find_element_by_xpath('//*[@id="text"]').text

			print(title)
			print(contents)
		else:
			break


	sleep(100)

