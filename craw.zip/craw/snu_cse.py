# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep
import re

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_num = 34641

while True:
	driver.get('https://cse.snu.ac.kr/department-notices?c%5B%5D=40&keys=')

	recent_href = driver.find_element_by_xpath('//*[@id="block-system-main"]/div/div/div[2]/table/tbody/tr[1]/td[1]/a').get_attribute('href')
	recent_num = re.findall("\d+", recent_href)[0]

	if int(recent_num) > last_num:
		driver.get(recent_href)
		title = driver.find_element_by_xpath('//*[@id="page-title"]').text
		contents = driver.find_element_by_xpath('//*[@id="node-34662"]/div[2]/div[2]/div/div').text

		print(title)
		print(contents)


	sleep(100)