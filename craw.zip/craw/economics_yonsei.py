# -*- coding: utf-8 -*- 
from selenium import webdriver
from time import sleep

driver = webdriver.Chrome('/Users/jeongjin-a/Desktop/craw/chromedriver')
driver.implicitly_wait(3)

last_num = 196


while True:
	driver.get('http://economics.yonsei.ac.kr/economics/community/job.do')

	recent_num = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/table/tbody/tr[1]/td[1]').text

	while True:
		if int(recent_num) > last_num:
			
			last_num=last_num+1
			driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div/div/table/tbody/tr[1]/td[2]').click()
			title = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div[1]/div/dl[1]/dd').text
			contents = driver.find_element_by_xpath('//*[@id="jwxe_main_content"]/div/div[1]/div/dl[4]/dd/div/p').text

			print(title)
			print(contents)
		else:
			break


	sleep(100)
