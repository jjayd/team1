package naver.board;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseFirestore mStore =FirebaseFirestore.getInstance();

    RecyclerView rcv;
    LinearLayoutManager llm;
    WrittingAdapter wadapter;
    private List<Board> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcv = (RecyclerView)findViewById(R.id.article_part);
        findViewById(R.id.write_button).setOnClickListener(this);

        llm = new LinearLayoutManager(this);
        rcv.setHasFixedSize(true);
        rcv.setLayoutManager(llm);

        list = new ArrayList<>();
        mStore.collection("board")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@NonNull QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                    for(DocumentChange dc : queryDocumentSnapshots.getDocumentChanges()){
                        String id = (String)dc.getDocument().getData().get("id");
                        String title = (String)dc.getDocument().getData().get("title");
                        String contents = (String)dc.getDocument().getData().get("contents");
                        String name = (String)dc.getDocument().getData().get("name");
                        Board data = new Board(id,title,contents,name);

                        list.add(data);
                    }
                    wadapter = new WrittingAdapter(list);
                    rcv.setAdapter(wadapter);
            }
        });
    }

    @Override
    public void onClick(View v){
        startActivity(new Intent(this, WriteActivity.class));
    }


}
