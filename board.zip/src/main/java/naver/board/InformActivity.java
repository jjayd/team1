package naver.board;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class InformActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inform);

        TextView mInformTitleView;

        Intent intent = getIntent();
        String data = intent.getStringExtra("value");

        mInformTitleView = (TextView) findViewById(R.id.inform_title_text);
        mInformTitleView.setText(data);

        findViewById(R.id.inform_exit_button).setOnClickListener(this);

    }
    public void onClick(View view){
        finish();
    }
}
